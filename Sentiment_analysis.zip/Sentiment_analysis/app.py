import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import re
import string
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

st.set_page_config(
    page_title="Zomato vs Swiggy Comparison Dashboard",
    page_icon="🍽️",
    layout="wide"
)

nltk.download("vader_lexicon")
sia = SentimentIntensityAnalyzer()

# ----------------------------
# Helper functions
# ----------------------------
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+|https\S+", "", text)
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"#\w+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\s+", " ", text).strip()
    return text

def detect_platform(text):
    text = str(text).lower()
    has_zomato = "zomato" in text
    has_swiggy = "swiggy" in text

    if has_zomato and not has_swiggy:
        return "Zomato"
    elif has_swiggy and not has_zomato:
        return "Swiggy"
    elif has_zomato and has_swiggy:
        return "Both"
    else:
        return "Unknown"

def get_sentiment(text):
    score = sia.polarity_scores(text)["compound"]
    if score >= 0.05:
        return "Positive"
    elif score <= -0.05:
        return "Negative"
    else:
        return "Neutral"

def get_platform_scores(dataframe):
    comparison = pd.crosstab(dataframe["platform"], dataframe["final_sentiment_mapped"])

    for col in ["Positive", "Negative", "Neutral"]:
        if col not in comparison.columns:
            comparison[col] = 0

    comparison = comparison[["Positive", "Negative", "Neutral"]]
    comparison["Total"] = comparison.sum(axis=1)
    comparison["Positive %"] = (comparison["Positive"] / comparison["Total"]) * 100
    comparison["Negative %"] = (comparison["Negative"] / comparison["Total"]) * 100
    comparison["Neutral %"] = (comparison["Neutral"] / comparison["Total"]) * 100
    comparison["Score"] = comparison["Positive"] - comparison["Negative"]

    return comparison

def get_winner_text(comparison):
    if "Zomato" not in comparison.index or "Swiggy" not in comparison.index:
        return "Not enough data to compare both apps.", "", ""

    zomato_score = comparison.loc["Zomato", "Score"]
    swiggy_score = comparison.loc["Swiggy", "Score"]

    zomato_pos = comparison.loc["Zomato", "Positive %"]
    swiggy_pos = comparison.loc["Swiggy", "Positive %"]

    zomato_neg = comparison.loc["Zomato", "Negative %"]
    swiggy_neg = comparison.loc["Swiggy", "Negative %"]

    if zomato_score > swiggy_score:
        short_line = "Based on the available reviews and tweets, Zomato appears to be the better app."
        summary = (
            f"Zomato is performing better overall because it has a higher positive sentiment "
            f"share ({zomato_pos:.2f}%) and better sentiment balance than Swiggy."
        )
    elif swiggy_score > zomato_score:
        short_line = "Based on the available reviews and tweets, Swiggy appears to be the better app."
        summary = (
            f"Swiggy is performing better overall because it has a higher positive sentiment "
            f"share ({swiggy_pos:.2f}%) and better sentiment balance than Zomato."
        )
    else:
        short_line = "Based on the available reviews and tweets, both apps perform similarly."
        summary = (
            f"Both apps have very similar sentiment scores. "
            f"Zomato Positive: {zomato_pos:.2f}% | Swiggy Positive: {swiggy_pos:.2f}%."
        )

    details = (
        f"Zomato → Positive: {zomato_pos:.2f}%, Negative: {zomato_neg:.2f}% | "
        f"Swiggy → Positive: {swiggy_pos:.2f}%, Negative: {swiggy_neg:.2f}%"
    )

    return short_line, summary, details

# ----------------------------
# Load and process dataset
# ----------------------------
df = pd.read_csv("zomato_vs_swiggy_clean.csv")

df = df.dropna(subset=["tweetText"]).copy()
df["cleaned_text"] = df["tweetText"].apply(clean_text)
df["platform"] = df["tweetText"].apply(detect_platform)
df = df[df["platform"].isin(["Zomato", "Swiggy"])].copy()
df["final_sentiment_mapped"] = df["cleaned_text"].apply(get_sentiment)

if "createdAt" in df.columns:
    df["createdAt"] = pd.to_datetime(df["createdAt"], errors="coerce")

comparison = get_platform_scores(df)
short_line, summary, details = get_winner_text(comparison)

# ----------------------------
# Sidebar
# ----------------------------
st.sidebar.title("📌 Project Overview")
st.sidebar.write("""
This project compares **Zomato** and **Swiggy** using sentiment analysis on tweets and reviews.

### Features
- Text cleaning
- Live sentiment prediction
- App detection
- App-wise comparison
- Final verdict
- Visual analytics
""")

zomato_count = (df["platform"] == "Zomato").sum()
swiggy_count = (df["platform"] == "Swiggy").sum()
positive_total = (df["final_sentiment_mapped"] == "Positive").sum()
negative_total = (df["final_sentiment_mapped"] == "Negative").sum()
neutral_total = (df["final_sentiment_mapped"] == "Neutral").sum()

st.sidebar.metric("Zomato Posts", zomato_count)
st.sidebar.metric("Swiggy Posts", swiggy_count)
st.sidebar.metric("Positive Posts", positive_total)
st.sidebar.metric("Negative Posts", negative_total)
st.sidebar.metric("Neutral Posts", neutral_total)

# ----------------------------
# Main Title
# ----------------------------
st.title("🍔 Zomato vs Swiggy Sentiment Comparison Dashboard")
st.markdown("This dashboard compares **Zomato** and **Swiggy** using available **reviews and tweets sentiment data**.")

m1, m2, m3, m4 = st.columns(4)
m1.metric("Zomato Posts", zomato_count)
m2.metric("Swiggy Posts", swiggy_count)
m3.metric("Positive Posts", positive_total)
m4.metric("Negative Posts", negative_total)

st.markdown("---")

tab1, tab2, tab3, tab4 = st.tabs([
    "🏆 Final Verdict",
    "📝 Prediction",
    "📊 Visualizations",
    "📂 Dataset Preview"
])

# ----------------------------
# Tab 1: Final Verdict
# ----------------------------
with tab1:
    st.subheader("Which App is Better?")

    if "better app" in short_line.lower():
        st.success(short_line)
    else:
        st.info(short_line)

    st.write(summary)
    st.write(details)

    st.markdown("### Comparison Table")
    st.dataframe(
        comparison[["Positive", "Negative", "Neutral", "Total", "Positive %", "Negative %", "Score"]],
        use_container_width=True
    )

    st.markdown("### Final Conclusion")
    if "Zomato appears to be the better app" in short_line:
        st.success("Final Conclusion: Based on available reviews and tweets, **Zomato is the better app**.")
    elif "Swiggy appears to be the better app" in short_line:
        st.success("Final Conclusion: Based on available reviews and tweets, **Swiggy is the better app**.")
    else:
        st.info("Final Conclusion: Based on available reviews and tweets, **both apps perform similarly**.")

# ----------------------------
# Tab 2: Prediction
# ----------------------------
with tab2:
    st.subheader("Predict Sentiment for a New Review or Tweet")

    user_text = st.text_area("Enter a review or tweet about Zomato or Swiggy")

    if st.button("Analyze Sentiment"):
        if user_text.strip() == "":
            st.warning("Please enter some text.")
        else:
            cleaned = clean_text(user_text)
            platform_name = detect_platform(user_text)

            score = sia.polarity_scores(cleaned)
            compound = score["compound"]

            if compound >= 0.05:
                prediction = "Positive"
                confidence = score["pos"] * 100
            elif compound <= -0.05:
                prediction = "Negative"
                confidence = score["neg"] * 100
            else:
                prediction = "Neutral"
                confidence = score["neu"] * 100

            st.write(f"**Detected App:** {platform_name}")
            st.write(f"**Predicted Sentiment:** {prediction}")
            st.write(f"**Confidence Score:** {confidence:.2f}%")

            if prediction == "Positive":
                st.success("This text shows a positive opinion.")
            elif prediction == "Negative":
                st.error("This text shows a negative opinion.")
            else:
                st.info("This text shows a neutral opinion.")

# ----------------------------
# Tab 3: Visualizations
# ----------------------------
with tab3:
    st.subheader("Comparison Visualizations")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### 1. Overall Sentiment Distribution")
        sentiment_counts = df["final_sentiment_mapped"].value_counts()

        fig1, ax1 = plt.subplots(figsize=(4, 4))
        ax1.pie(sentiment_counts, labels=sentiment_counts.index, autopct="%1.1f%%")
        ax1.set_title("Overall Sentiment Distribution", fontsize=10)
        st.pyplot(fig1)

    with col2:
        st.markdown("#### 2. Zomato vs Swiggy Sentiment Count")
        fig2, ax2 = plt.subplots(figsize=(5, 3))
        comparison[["Positive", "Negative", "Neutral"]].plot(kind="bar", ax=ax2)
        ax2.set_title("Platform-wise Sentiment Comparison", fontsize=10)
        ax2.set_xlabel("App", fontsize=8)
        ax2.set_ylabel("Number of Posts", fontsize=8)
        plt.xticks(rotation=0)
        st.pyplot(fig2)

    col3, col4 = st.columns(2)

    with col3:
        if "likeCount" in df.columns:
            st.markdown("#### 3. Average Likes by App")
            likes_by_platform = df.groupby("platform")["likeCount"].mean()

            fig3, ax3 = plt.subplots(figsize=(5, 3))
            likes_by_platform.plot(kind="bar", ax=ax3)
            ax3.set_title("Average Likes by App", fontsize=10)
            ax3.set_xlabel("App", fontsize=8)
            ax3.set_ylabel("Average Likes", fontsize=8)
            plt.xticks(rotation=0)
            st.pyplot(fig3)

    with col4:
        if "retweetCount" in df.columns:
            st.markdown("#### 4. Average Retweets by App")
            retweets_by_platform = df.groupby("platform")["retweetCount"].mean()

            fig4, ax4 = plt.subplots(figsize=(5, 3))
            retweets_by_platform.plot(kind="bar", ax=ax4)
            ax4.set_title("Average Retweets by App", fontsize=10)
            ax4.set_xlabel("App", fontsize=8)
            ax4.set_ylabel("Average Retweets", fontsize=8)
            plt.xticks(rotation=0)
            st.pyplot(fig4)

    if "createdAt" in df.columns:
        df_time = df.dropna(subset=["createdAt"]).copy()
        if not df_time.empty:
            df_time["date"] = df_time["createdAt"].dt.date
            trend = df_time.groupby(["date", "platform"]).size().unstack(fill_value=0)

            st.markdown("#### 5. Review/Tweet Trend Over Time")
            fig5, ax5 = plt.subplots(figsize=(8, 4))
            trend.plot(ax=ax5)
            ax5.set_title("Review/Tweet Trend Over Time by App", fontsize=10)
            ax5.set_xlabel("Date", fontsize=8)
            ax5.set_ylabel("Number of Posts", fontsize=8)
            plt.xticks(rotation=45)
            st.pyplot(fig5)

# ----------------------------
# Tab 4: Dataset Preview
# ----------------------------
with tab4:
    st.subheader("Dataset Preview")

    platform_filter = st.selectbox("Filter by App", ["All", "Zomato", "Swiggy"])
    keyword = st.text_input("Search by Keyword")

    preview_df = df.copy()

    if platform_filter != "All":
        preview_df = preview_df[preview_df["platform"] == platform_filter]

    if keyword.strip():
        preview_df = preview_df[
            preview_df["tweetText"].astype(str).str.contains(keyword, case=False, na=False)
        ]

    cols = ["tweetText", "platform", "cleaned_text", "final_sentiment_mapped"]
    available_cols = [c for c in cols if c in preview_df.columns]

    st.dataframe(preview_df[available_cols].head(30), use_container_width=True)

    csv_data = preview_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="Download Filtered Data",
        data=csv_data,
        file_name="zomato_swiggy_filtered_data.csv",
        mime="text/csv"
    )