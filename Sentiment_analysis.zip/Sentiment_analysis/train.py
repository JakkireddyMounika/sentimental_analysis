import pandas as pd
import pickle
import re
import string
import nltk

from nltk.sentiment import SentimentIntensityAnalyzer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression

nltk.download("vader_lexicon")

# Load dataset
df = pd.read_csv("zomato_vs_swiggy_clean.csv")

print("Columns in dataset:", df.columns.tolist())

# Keep only rows with tweet text
df = df.dropna(subset=["tweetText"]).copy()

# Clean text
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+|https\S+", "", text)
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"#\w+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\s+", " ", text).strip()
    return text

df["cleaned_text"] = df["tweetText"].apply(clean_text)

# Detect platform from tweet text
def detect_platform(text):
    text = str(text).lower()
    has_zomato = "zomato" in text
    has_swiggy = "swiggy" in text

    if has_zomato and not has_swiggy:
        return "Zomato"
    elif has_swiggy and not has_zomato:
        return "Swiggy"
    elif has_zomato and has_swiggy:
        return "Both"
    else:
        return "Unknown"

df["platform"] = df["tweetText"].apply(detect_platform)

# Keep only Zomato and Swiggy specific tweets
df = df[df["platform"].isin(["Zomato", "Swiggy"])].copy()

# Sentiment using VADER
sia = SentimentIntensityAnalyzer()

def get_sentiment(text):
    score = sia.polarity_scores(text)["compound"]
    if score >= 0.05:
        return "Positive"
    elif score <= -0.05:
        return "Negative"
    else:
        return "Neutral"

df["final_sentiment_mapped"] = df["cleaned_text"].apply(get_sentiment)

# Remove empty text rows
df = df[df["cleaned_text"].str.strip() != ""]

# Train simple ML model
X = df["cleaned_text"]
y = df["final_sentiment_mapped"]

vectorizer = CountVectorizer()
X_vec = vectorizer.fit_transform(X)

model = LogisticRegression(max_iter=1000)
model.fit(X_vec, y)

# Save processed dataset
df.to_csv("processed_sentiment_data.csv", index=False)

# Save model and vectorizer
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)

print("Processed dataset saved as processed_sentiment_data.csv")
print("Model and vectorizer saved successfully")
print(df["platform"].value_counts())
print(df["final_sentiment_mapped"].value_counts())